import pandas as pd
titanic=pd.read_csv('titanic.csv',encoding="shift-jis")
from sklearn.feature_extraction import DictVectorizer
def one_hot_dataframe(data, cols, replace=False):
    """ Takes a dataframe and a list of columns that need to be encoded.
        Returns a 3-tuple comprising the data, the vectorized data,
        and the fitted vectorizor."""
    vec = DictVectorizer(sparse=False)
    vecData = pd.DataFrame(vec.fit_transform(data[cols].T.to_dict().values()))
    vecData.columns = vec.get_feature_names()
    vecData.index = data.index
    if replace is True:
        data = data.drop(cols, axis=1)
        data = data.join(vecData)
    return (data, vecData, vec)

titanic=one_hot_dataframe(titanic,['pclass','embarked','sex','home.dest','room','ticket','boat'],replace=True)
mean=titanic[0]['age'].mean()
titanic[0]['age'].fillna(mean,inplace=True)
titanic[0].fillna(0,inplace=True)
from sklearn.model_selection import train_test_split
titanic_target = titanic[0]['survived']
titanic_data=titanic[0].drop(['name','row.names','survived'],axis=1)
X_train,X_test,y_train,y_test=train_test_split(titanic_data,titanic_target,test_size=0.25,random_state=33)
from sklearn import tree
from sklearn import feature_selection
clf=tree.DecisionTreeClassifier()
fs = feature_selection.SelectPercentile(feature_selection.chi2,percentile=20)
X_train_fs = fs.fit_transform(X_train,y_train)
clf.fit(X_train_fs,y_train)
X_test_fs = fs.transform(X_test)
y_pred_fs=clf.predict(X_test_fs)
from sklearn import metrics
print (metrics.accuracy_score(y_test,y_pred_fs))
