import numpy as np
import pandas as pd
titanic=pd.read_csv('titanic.csv',encoding="shift-jis")
from sklearn.feature_extraction import DictVectorizer
def one_hot_dataframe(data, cols, replace=False):
    """ Takes a dataframe and a list of columns that need to be encoded.
        Returns a 3-tuple comprising the data, the vectorized data,
        and the fitted vectorizor."""
    vec = DictVectorizer(sparse=False)
    vecData = pd.DataFrame(vec.fit_transform(data[cols].T.to_dict().values()))
    vecData.columns = vec.get_feature_names()
    vecData.index = data.index
    if replace is True:
        data = data.drop(cols, axis=1)
        data = data.join(vecData)
    return (data, vecData, vec)

titanic=one_hot_dataframe(titanic,['pclass','embarked','sex','home.dest','room','ticket','boat'],replace=True)
mean=titanic[0]['age'].mean()
titanic[0]['age'].fillna(mean,inplace=True)
titanic[0].fillna(0,inplace=True)
from sklearn.model_selection import train_test_split
titanic_target = titanic[0]['survived']
titanic_data=titanic[0].drop(['name','row.names','survived'],axis=1)
X_train,X_test,y_train,y_test=train_test_split(titanic_data,titanic_target,test_size=0.25,random_state=33)
from sklearn.ensemble import ExtraTreesClassifier
from sklearn import feature_selection
clf=ExtraTreesClassifier(n_estimators=382, max_depth=None,min_samples_split=2, random_state=0)
from sklearn.model_selection import cross_val_score
percentiles=range(1,100,5)
results=[]
for i in range(1,100,5):
 fs=feature_selection.SelectPercentile(feature_selection.chi2,percentile=i)
 X_train_fs = fs.fit_transform(X_train,y_train)
 scores=cross_val_score(clf,X_train_fs,y_train,cv=5)
 results=np.append(results,scores.mean())
optimal_percentil = np.where(results == results.max())[0]
import matplotlib.pyplot as pl
pl.xlabel("number of features selected")
pl.ylabel("cross-validation accuracy")
pl.plot(percentiles,results,'-')
pl.show()
A=max(results)
print (A,pd.Series(results).idxmax())
